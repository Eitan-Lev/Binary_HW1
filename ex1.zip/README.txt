Eitan Levin	304986276
Roy Hirsch	203538806
------------------------------------------------------------------------------
+++how to compile+++

1. copy 'ex1.cpp' to:

	pin-3.6-97554-g31f0a167d-gcc-linux/source/tools/SimpleExamples

2. from this working directory,run the command: 

	make ex1.test
	
------------------------------------------------------------------------------
+++how to run+++

3. copy the file ex1.so from ../SimpleExamples/obj-intel64 to your desired folder

4. run the pintool using the command:

time pin-3.6-97554-g31f0a167d-gcc-linux/pin -t ex1.so -- ./bzip2 -k -f input.txt

or

time pin-3.6-97554-g31f0a167d-gcc-linux/pin -t ex1.so -- ./tst

where the last argument is the program to run.
------------------------------------------------------------------------------

+++how to read output+++

5. open 'rtn-output.csv'.

